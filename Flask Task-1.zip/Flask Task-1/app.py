from flask import Flask, request

app = Flask(__name__)

@app.route('/')
def home():
    name = request.args.get('name')
    if name:
        return name.upper()
    return "Please provide a name like this: ?name=sakshi"

@app.route('/greet')
def greet():
    name = request.args.get('name')
    if name:
        return f"Hello {name.upper()}! Welcome to my Flask App"
    return "Please provide a name like this: /greet?name=sakshi"

if __name__ == '__main__':
    app.run(debug=True)
